# Reactify-Django UI


This is the react portion of the **Reactify Django** project. To get it working locally just do:

```
npm install
``` 

To bring into django, run:
```
npm run collect
```