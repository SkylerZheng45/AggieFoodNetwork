from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, get_user_model
from ecommerce.forms import ContactForm, LoginForm, RegisterForm


def home_page(request):
    premium_content = ''
    if request.user.is_authenticated:
        premium_content = 'stuff'

    return render(request, 'home_page.html', context={
        'title': 'hello world',
        'content': 'Welcome to the home page',
        'premium_content': premium_content
    })


def about_page(request):
    return render(request, 'home_page.html', context={
        'title': 'About Page',
        'content': 'Welcome to the about page'
    })


def contact_page(request):
    contact_form = ContactForm(request.POST or None)

    if contact_form.is_valid():
        print(contact_form.cleaned_data)

    # if request.method == 'POST':
    #     print(request.POST)

    return render(request, 'contact/view.html', context={
        'title': 'Contact',
        'content': 'Welcome to the contact page',
        'form': contact_form
    })


def login_page(request):
    form = LoginForm(request.POST or None)
    # print(f'User logged in: {request.user.is_authenticated}')

    if form.is_valid():
        print(form.cleaned_data)
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        user = authenticate(request, username=username, password=password)
        print(user)
        # print(f'User logged in: {request.user.is_authenticated}')
        if user is not None:
            # print(f'User logged in: {request.user.is_authenticated}')
            login(request, user)
            return redirect('/')
        else:
            print('Error')

    return render(request, 'auth/login.html', context={
        'form': form
    })


def register_page(request):
    form = RegisterForm(request.POST or None)

    if form.is_valid():
        print(form.cleaned_data)

        email = form.cleaned_data.get('email')
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        new_user = get_user_model().objects.create_user(username, email, password)
        print(new_user)

    return render(request, 'auth/register.html', context={
        'form': form
    })
